import useMsgPopupStore from '../stores/useMsgPopupStore'
import useLoginStore from '../stores/useLoginStore'
import * as loginSvc from '../services/LoginSvc'

export default function useLoginHandler(){
    const store = useLoginStore();
    const msgStore = useMsgPopupStore();
    
    const result = {}

    result.login = () => {
        if (!validate()) return;
    }

    
    const validate = async() => {
        if (store.admin.username === "") {
            showMsg('Error', 'Please input username.')
            return false;
        }
        if (store.admin.password === "") {
            showMsg('Error', 'Please input password.')
            return false;
        }
        await loginSvc.checkToken(store.admin);

    }
    const showMsg = (title, message) => {
        msgStore.setValue({ visible: true, title, message });
    }

    return result;
}