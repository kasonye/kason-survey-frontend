import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Thanks from '../../components/Thanks';

export default function Finish() {
  return (
    <Thanks />
  );
}